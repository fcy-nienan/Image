create function getChapters(id mediumtext, page int, pageSize int)
  returns text
  begin
    declare result text;
    declare start int;
    declare count int;
    set start=page*pageSize;

    select group_concat(concat(name,":",sequence)) as chapters
    into result from (
    select name,sequence from (
    select name,sequence from
          Chapter
          where book_id = id
          limit start, pageSize
      ) chapter
    order by sequence
    )t1;
    select count(*) into count from Chapter where book_id=id;
    set result=concat(result,",",count);
    return result;
end;

