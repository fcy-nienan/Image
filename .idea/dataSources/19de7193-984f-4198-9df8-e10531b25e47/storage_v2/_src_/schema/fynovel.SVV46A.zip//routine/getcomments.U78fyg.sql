create function getComments(id mediumtext, page int, pageSize int)
  returns text
  begin
    declare result text;
    declare start int;
    declare count int;
    set start=page*pageSize;
    select group_concat(concat(username,"#",ct,"#",content)) as comment
      into result
      from (
             select username,ct,content
             from User, Comment
             where
               Comment.user_id = User.id and book_id = id limit start,pageSize
           ) t;
    select count(*) into count from Comment where book_id=id;
    set result=concat(result,",",count);
    return result;
end;

